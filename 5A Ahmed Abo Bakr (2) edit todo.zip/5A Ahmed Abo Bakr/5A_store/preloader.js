// /preloader js styling

let preloader = document.querySelector("#preloader");

window.addEventListener("load",function(e){

    preloader.style.display = "none";

});